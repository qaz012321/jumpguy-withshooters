# jumpguy-withshooters
idk

**GamePlay Description:** rules, goals, levels(if applicable), UML class diagrams

You are hallucinating and you see a door on the other side of the room. You want the hallucinations to stop, and you think that the door might make you leave your hallucinations. Your goal is to leave each room through the door to get to the next room until you finally snap out of your hallucinations.

OR

You are hallucinating and are trapped in some sort of giant room with way too many platforms and way too many monsters. You want the hallucinations to stop, and you think that there may be a door at the other end of the room that will help you escape this surreal experience. Your goal is to reach the door in each room to get to the next room until you finally snap out of your hallucinations.

E.g. moving character, moving enemies, stationary enemies, shooting/bullets, death zones, jumping & gravity, scrolling bg, point/score system, time system, levels, end zone, boss(maybe?), pausing(maybe?)


**Describe user  
interactions**
- 8 possible keys to move
- 1 key to shoot
- 1 key to pause?
- Mouse to select option on title screen and menus


**Which techniques** do you  need for implementation (At least one)
Y=Yes   M=Maybe/Unsure

Collision           = Y

Gravity/Jumping     = Y

image rotation      = N

moving at an angle  = N

background scroll   = Y

relative movement   = Y

Fixed object        = Y

animated character  = M

Tracking time       = Y

Array list          = M

Tile based game     = N

mouse selection     = Y

Shooting            = Y


**Timeline**
1st Draft - design, game plan    - Dec 25
2nd Draft - functional code      - Jan 15
Final - debug/testing            - Jan 20-23

